<?php

namespace common\models\query;

/**
 * This is the ActiveQuery class for [[\common\models\Approved]].
 *
 * @see \common\models\Approved
 */
class ApprovedQuery extends \yii\db\ActiveQuery
{
    /*public function active()
    {
        return $this->andWhere('[[status]]=1');
    }*/

    /**
     * @inheritdoc
     * @return \common\models\Approved[]|array
     */
    public function all($db = null)
    {
        return parent::all($db);
    }

    /**
     * @inheritdoc
     * @return \common\models\Approved|array|null
     */
    public function one($db = null)
    {
        return parent::one($db);
    }
}
